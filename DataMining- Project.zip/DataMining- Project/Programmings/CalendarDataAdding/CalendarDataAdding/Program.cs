﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalendarDataAdding
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] lines = File.ReadAllLines(@"D:\University\Terms\Term 5\Data Mining\Project\Data_94_Tehran-Karaj_km25\TotalNew.csv");
            string[] holidays = File.ReadAllLines(@"D:\University\Terms\Term 5\Data Mining\Project\Data_94_Tehran-Karaj_km25\Holidays.txt");
            string[] newlines = new string[lines.Length];

            for (int i = 0; i < lines.Length;i++ )
            {
                string line = lines[i];
                string[] parameters = line.Split(',');

                DateTime dt = new DateTime(Convert.ToInt32(parameters[0].Split('/')[0]), Convert.ToInt32(parameters[0].Split('/')[1]), Convert.ToInt32(parameters[0].Split('/')[2]), new PersianCalendar());
                PersianCalendar pc = new PersianCalendar();

                bool tmp = false;
                foreach (string item in holidays)
                {
                    string pcdate = pc.GetYear(dt.AddDays(1)) + "/" + pc.GetMonth(dt.AddDays(1)).ToString("00") + "/" + pc.GetDayOfMonth(dt.AddDays(1)).ToString("00");
                    if (pcdate.Equals(item))
                    {
                        tmp = true;
                    }
                }

                if (tmp || pc.GetDayOfWeek(dt) == DayOfWeek.Wednesday || pc.GetDayOfWeek(dt) == DayOfWeek.Thursday)
                {
                    newlines[i] = line + ",1";
                }
                else
                {
                    newlines[i] = line + ",0";
                }
            }

            File.WriteAllLines(@"D:\University\Terms\Term 5\Data Mining\Project\Data_94_Tehran-Karaj_km25\TotalNN.csv", newlines);

        }
    }
}
