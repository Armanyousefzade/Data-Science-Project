﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MergerWeather
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> lines = new List<string>();

            string[] files = Directory.GetFiles(@"c:\users\ariyan\desktop\", "*.txt", SearchOption.TopDirectoryOnly);
            string[] MainData = File.ReadAllLines(@"c:\users\ariyan\desktop\TotalNew.csv");
            string[] newlines= new string[MainData.Length];

            foreach (string item in files)
            {
                foreach (string item2 in File.ReadAllLines(item))
                {
                    lines.Add(item2);
                }
            }

            string Date;
            int y;
            int m;
            int d;
            string newdate;

            for (int i = 0; i < newlines.Length; i++)
            {
                newlines[i] = MainData[i];

                foreach (string item in lines)
                {
                    Date = item.Split(',')[0];
                    y = Convert.ToInt32(Date.Split('/')[0]);
                    m = Convert.ToInt32(Date.Split('/')[1]);
                    d = Convert.ToInt32(Date.Split('/')[2]);

                    newdate = y.ToString("0000") + "/" + m.ToString("00") + "/" + d.ToString("00");

                    if (newlines[i].Split(',')[0].Equals(newdate))
                    {
                        newlines[i] += "," + item;
                    }
                }
            }

            File.WriteAllLines(@"c:\users\ariyan\desktop\aaa.txt",newlines);
        }
    }
}
