﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataNormalizor
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.BufferWidth = 100;
            Console.BufferHeight = 500;
            Console.WindowWidth = 100;

            string[] lines = File.ReadAllLines("C:\\users\\ariyan\\desktop\\Total.csv");
            string[,] matrix = new string[lines.Length,15];

            for (int i = 0; i < lines.Length; i++)
            {
                string item = lines[i];

                string[] tmp = item.Split(',');

                for (int j = 0; j < tmp.Length; j++)
                {
                    matrix[i, j] = tmp[j];
                }
            }

            string[,] matrixnew = new string[lines.Length, 19];

            for (int i = 0; i < lines.Length; i++)
            {

                for (int j = 0; j < 15; j++)
                {
                    matrixnew[i, j] = matrix[i, j];
                }

                PersianCalendar pc = new PersianCalendar();
                DateTime dt = new DateTime(Convert.ToInt32(matrix[i, 0].Split('/')[0]), Convert.ToInt32(matrix[i, 0].Split('/')[1]), Convert.ToInt32(matrix[i, 0].Split('/')[2]), pc);
                matrixnew[i, 15] = pc.GetDayOfWeek(dt).ToString();
                matrixnew[i, 16] = pc.GetDayOfWeek(dt).ToString();
                matrixnew[i, 15] = pc.GetDayOfWeek(dt).ToString();
                matrixnew[i, 15] = pc.GetDayOfWeek(dt).ToString();
                
                //matrixnew[i, 0] = matrix[i, 0].Substring(0, 10);
                //matrixnew[i, 1] = matrix[i, 0].Substring(11, 8);

                //matrixnew[i, 2] = matrix[i, 1].Substring(0, 10);
                //matrixnew[i, 3] = matrix[i, 1].Substring(11, 8);

            }

            string[] newlines = new string[lines.Length];

            string temp = string.Empty;
            for (int i = 0; i < lines.Length; i++)
            {
                temp = string.Empty;

                for (int j = 0; j < 19; j++)
                {
                    temp += matrixnew[i, j] + ",";    
                }

                temp = temp.Substring(0, temp.Length - 1);
                newlines[i] = temp;
            }

            File.WriteAllLines("C:\\users\\ariyan\\desktop\\TotalNew.csv", newlines);

            Console.ReadKey();
        }
    }
}
