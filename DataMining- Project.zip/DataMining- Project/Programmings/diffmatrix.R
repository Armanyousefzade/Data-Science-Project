
diffmatrix = matrix(0,24,24)

minvector = matrix(0,1,31)
maxvector = matrix(0,1,31)

for(i in 1:31)
{
  minvector[i] = min(TotalData[,i])
  maxvector[i] = max(TotalData[,i])
}

for(i in 1:24)
{
  for(j in 1:24)
  {
    sumsigma = 0
    sumsigmadiff = 0
    
    for(k in 1:31)
    {
      sig = 0
      dif = 0
      
      if(TotalData[i,k] != 0 | TotalData[j,k] != 0)
      {
        sig = 1
      }
      
      dif = abs(TotalData[i,k] - TotalData[j,k])
      
      if(!(k == 20 |k == 21 |k == 24 |k == 27 ) & sig != 0)
      {
        dif = dif/(maxvector[k]-minvector[k])
      }
      
      sumsigmadiff = sumsigmadiff + (dif*sig)
      
      sumsigma = sumsigma + sig
      
    }
    
    diffmatrix[i,j] = round(sumsigmadiff/sumsigma,2)
    diffmatrix[i,j]
  }
}