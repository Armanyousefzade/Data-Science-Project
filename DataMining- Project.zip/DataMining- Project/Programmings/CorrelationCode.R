
correlationmat = matrix(NA,32,32)

for(i in 1:31)
{
  correlationmat[i,1] = names(TotalData)[i]
  correlationmat[1,i] = names(TotalData)[i]
}

for(i in c(1,2,3,4,6,7,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,25,26,28,29,30,31))
{
  for(j in c(1,2,3,4,6,7,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,25,26,28,29,30,31))
  {
    correlationmat[i+1,j+1] = round(cor(TotalData[,c(i)],TotalData[,c(j)]),2)
  }
}

