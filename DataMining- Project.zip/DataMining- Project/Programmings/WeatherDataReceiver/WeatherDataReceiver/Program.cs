﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json;
using System.Globalization;

namespace WeatherDataReceiver
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("From: ");
            string fromdate = Console.ReadLine();
            Console.Write("To: ");
            string todate = Console.ReadLine();

            var request = (HttpWebRequest)WebRequest.Create(string.Format("http://api.worldweatheronline.com/premium/v1/past-weather.ashx?key=06b3d1f23cf846fa954105217160311&q=Tehran&format=json&date={0}&enddate={1}",fromdate,todate));
            var response = (HttpWebResponse)request.GetResponse();
            var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
            RootObject r = JsonConvert.DeserializeObject<RootObject>(responseString);

            string Text = "";
            DateTime d ;
            PersianCalendar pc ;
            int i = 0;

            foreach (Weather w in r.data.weather)
            {
                d = DateTime.Parse(w.date);
                pc = new PersianCalendar();
                var tmpc = from a in w.hourly
                           select a.tempC;
                var modcode = w.hourly.GroupBy(a=>a.weatherCode);
                var visib = from a in w.hourly
                            select a.visibility;
                var cloud = from a in w.hourly
                            select a.cloudcover;

                Text+=string.Format("{0},{1},{2},{3},{4},{5},{6}",string.Format("{0}/{1}/{2}", pc.GetYear(d), pc.GetMonth(d), pc.GetDayOfMonth(d))
                                          ,w.astronomy.FirstOrDefault().sunrise
                                          , w.astronomy.FirstOrDefault().sunset
                                          ,tmpc.Average(a=>Convert.ToDecimal(a))
                                          ,modcode.First(b=>b.Count() == modcode.Max(c=>c.Count())).Key
                                          ,visib.Average(a=>Convert.ToDecimal(a))
                                          ,cloud.Average(a=>Convert.ToDecimal(a)));
                Text += Environment.NewLine;
                i++;
            }

            File.WriteAllText(string.Format(@"c:\users\ariyan\desktop\({0})-({1}).txt",fromdate,todate), Text);

            Console.WriteLine("{0} rows wrote...", i);

            Console.ReadKey();
        }
    }
}
